@extends('layouts.app')

@section('content')
<div class="container">
    <calendar-component></calendar-component>
</div>
@endsection
