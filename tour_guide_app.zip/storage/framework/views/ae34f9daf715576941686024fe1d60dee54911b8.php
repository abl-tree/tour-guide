<?php echo e($slot); ?>

<?php /**PATH D:\Projects\tour_guide_app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>